define({
  name: "Contacts",
  version: "0.0.1",
  description: "Contact Manager App",
  title: "Documentation for Contact Manager App",
  url: "http://localhost:3000",
  sampleUrl: false,
  defaultVersion: "0.0.0",
  apidoc: "0.3.0",
  generator: {
    name: "apidoc",
    time: "2017-11-09T18:33:57.706Z",
    url: "http://apidocjs.com",
    version: "0.17.6",
  },
});
